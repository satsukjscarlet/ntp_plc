<?php

use App\Http\Controllers\MachineController;
use App\Http\Controllers\PlantController;
use App\Http\Controllers\PlcController;
use App\Http\Controllers\PlcTagController;
use App\Http\Controllers\ProductionLineController;
use Illuminate\Support\Facades\Route;

Route::middleware(['auth', 'active'])->group(function (): void {
    Route::resource('plants', PlantController::class)->except('show');
    Route::resource('production-lines', ProductionLineController::class)
        ->parameters(['production-lines' => 'productionLine'])
        ->except('show');
    Route::resource('machines', MachineController::class)->except('show');
    Route::resource('plcs', PlcController::class)->except('show');
    Route::resource('plc-tags', PlcTagController::class)
        ->parameters(['plc-tags' => 'plcTag'])
        ->except('show');
});
