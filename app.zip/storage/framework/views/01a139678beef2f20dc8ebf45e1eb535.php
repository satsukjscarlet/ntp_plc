<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo $__env->yieldContent('title', 'NTP_PLC'); ?></title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="<?php echo e(asset('css/admin.css')); ?>" rel="stylesheet">

    <?php echo $__env->yieldPushContent('styles'); ?>
</head>

<body>
    <div class="app-shell">
        <aside class="sidebar" id="sidebar">
            <div class="sidebar-brand">
                <div class="brand-mark">NTP</div>
                <div>
                    <div class="brand-title">NTP_PLC</div>
                    <div class="brand-subtitle">MES & OEE</div>
                </div>
            </div>

            <nav class="sidebar-nav">
                <a class="nav-item <?php echo e(request()->routeIs('dashboard') ? 'active' : ''); ?>"
                   href="<?php echo e(route('dashboard')); ?>">
                    <i class="bi bi-grid-1x2-fill"></i>
                    <span>Dashboard</span>
                </a>

                <div class="nav-section">Giám sát PLC</div>

                <?php $__empty_1 = true; $__currentLoopData = $sidebarMachines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sidebarMachine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="small text-uppercase text-muted px-3 pt-2 pb-1 fw-semibold">
                        <?php echo e($sidebarMachine->code); ?> - <?php echo e($sidebarMachine->name); ?>

                    </div>

                    <a class="nav-item <?php echo e(request()->routeIs('monitoring.technology') && request()->route('machineCode') === $sidebarMachine->code ? 'active' : ''); ?>"
                       href="<?php echo e(route('monitoring.technology', $sidebarMachine->code)); ?>">
                        <i class="bi bi-display"></i>
                        <span>Thông số công nghệ</span>
                    </a>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('plc-tags.view')): ?>
                        <a class="nav-item <?php echo e(request()->routeIs('monitoring-layout.*') && request()->route('machineCode') === $sidebarMachine->code ? 'active' : ''); ?>"
                           href="<?php echo e(route('monitoring-layout.index', $sidebarMachine->code)); ?>">
                            <i class="bi bi-grid-3x3-gap-fill"></i>
                            <span>Bố trí màn hình</span>
                        </a>

                        <a class="nav-item <?php echo e(request()->routeIs('machines.tags.*') && request()->route('machineCode') === $sidebarMachine->code ? 'active' : ''); ?>"
                           href="<?php echo e(route('machines.tags.index', $sidebarMachine->code)); ?>">
                            <i class="bi bi-tags-fill"></i>
                            <span>Quản lý tag</span>
                        </a>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <span class="nav-item disabled">
                        <i class="bi bi-exclamation-circle"></i>
                        <span>Chưa có máy hoạt động</span>
                    </span>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('plc-tags.configure-oee')): ?>
                    <a class="nav-item <?php echo e(request()->routeIs('oee-settings.*') || request()->routeIs('machines.oee-settings.*') ? 'active' : ''); ?>"
                       href="<?php echo e(route('oee-settings.index')); ?>">
                        <i class="bi bi-speedometer"></i>
                        <span>Cấu hình OEE</span>
                    </a>
                <?php endif; ?>

                <div class="nav-section">Thiết bị</div>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('plants.view')): ?>
                    <a class="nav-item <?php echo e(request()->routeIs('plants.*') ? 'active' : ''); ?>"
                       href="<?php echo e(route('plants.index')); ?>">
                        <i class="bi bi-building"></i>
                        <span>Nhà máy</span>
                    </a>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('production-lines.view')): ?>
                    <a class="nav-item <?php echo e(request()->routeIs('production-lines.*') ? 'active' : ''); ?>"
                       href="<?php echo e(route('production-lines.index')); ?>">
                        <i class="bi bi-diagram-3"></i>
                        <span>Dây chuyền</span>
                    </a>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('machines.view')): ?>
                    <a class="nav-item <?php echo e(request()->routeIs('machines.index') || request()->routeIs('machines.create') || request()->routeIs('machines.edit') ? 'active' : ''); ?>"
                       href="<?php echo e(route('machines.index')); ?>">
                        <i class="bi bi-gear-wide-connected"></i>
                        <span>Máy</span>
                    </a>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('plcs.view')): ?>
                    <a class="nav-item <?php echo e(request()->routeIs('plcs.*') ? 'active' : ''); ?>"
                       href="<?php echo e(route('plcs.index')); ?>">
                        <i class="bi bi-cpu-fill"></i>
                        <span>PLC</span>
                    </a>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('plc-tags.view')): ?>
                    <a class="nav-item <?php echo e(request()->routeIs('plc-tags.*') ? 'active' : ''); ?>"
                       href="<?php echo e(route('plc-tags.index')); ?>">
                        <i class="bi bi-tags-fill"></i>
                        <span>Tag PLC</span>
                    </a>
                <?php endif; ?>

                <div class="nav-section">Sản xuất</div>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('products.view')): ?>
                    <a class="nav-item <?php echo e(request()->routeIs('products.*') ? 'active' : ''); ?>"
                       href="<?php echo e(route('products.index')); ?>">
                        <i class="bi bi-box-seam-fill"></i>
                        <span>Danh mục sản phẩm</span>
                    </a>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('machine-product-standards.view')): ?>
                    <a class="nav-item <?php echo e(request()->routeIs('machine-product-standards.*') ? 'active' : ''); ?>"
                       href="<?php echo e(route('machine-product-standards.index')); ?>">
                        <i class="bi bi-sliders"></i>
                        <span>Định mức máy - sản phẩm</span>
                    </a>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('production-shifts.view')): ?>
                    <a class="nav-item <?php echo e(request()->routeIs('production-shifts.*') ? 'active' : ''); ?>"
                       href="<?php echo e(route('production-shifts.index')); ?>">
                        <i class="bi bi-clock"></i>
                        <span>Danh mục ca làm việc</span>
                    </a>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('downtime-reasons.view')): ?>
                    <a class="nav-item <?php echo e(request()->routeIs('downtime-reasons.*') ? 'active' : ''); ?>"
                       href="<?php echo e(route('downtime-reasons.index')); ?>">
                        <i class="bi bi-stopwatch-fill"></i>
                        <span>Nguyên nhân dừng</span>
                    </a>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('production-declarations.view')): ?>
                    <a class="nav-item <?php echo e(request()->routeIs('production-declarations.*') ? 'active' : ''); ?>"
                       href="<?php echo e(route('production-declarations.index')); ?>">
                        <i class="bi bi-clipboard2-check-fill"></i>
                        <span>Kiểm nhập sản lượng</span>
                    </a>
                <?php endif; ?>

                <div class="nav-section">OEE và báo cáo</div>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('production-declarations.view')): ?>
                    <a class="nav-item <?php echo e(request()->routeIs('oee-reports.*') ? 'active' : ''); ?>"
                       href="<?php echo e(route('oee-reports.index')); ?>">
                        <i class="bi bi-speedometer2"></i>
                        <span>Báo cáo OEE</span>
                    </a>

                    <a class="nav-item <?php echo e(request()->routeIs('production-reports.*') ? 'active' : ''); ?>"
                       href="<?php echo e(route('production-reports.daily-detail')); ?>">
                        <i class="bi bi-table"></i>
                        <span>Tình hình sản xuất ngày</span>
                    </a>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['users.view', 'roles.view', 'activity-logs.view'])): ?>
                    <div class="nav-section">Hệ thống</div>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('users.view')): ?>
                        <a class="nav-item <?php echo e(request()->routeIs('users.*') ? 'active' : ''); ?>"
                           href="<?php echo e(route('users.index')); ?>">
                            <i class="bi bi-people-fill"></i>
                            <span>Người dùng</span>
                        </a>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roles.view')): ?>
                        <a class="nav-item <?php echo e(request()->routeIs('roles.*') ? 'active' : ''); ?>"
                           href="<?php echo e(route('roles.index')); ?>">
                            <i class="bi bi-shield-lock-fill"></i>
                            <span>Vai trò và quyền</span>
                        </a>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('activity-logs.view')): ?>
                        <a class="nav-item <?php echo e(request()->routeIs('activity-logs.*') ? 'active' : ''); ?>"
                           href="<?php echo e(route('activity-logs.index')); ?>">
                            <i class="bi bi-clock-history"></i>
                            <span>Nhật ký</span>
                        </a>
                    <?php endif; ?>
                <?php endif; ?>
            </nav>

            <div class="sidebar-footer">
                <div>NTP_PLC v1.0</div>
                <small>Nhựa Tiền Phong</small>
            </div>
        </aside>

        <main class="main-area">
            <header class="topbar">
                <button class="btn btn-light d-lg-none" type="button" id="sidebarToggle">
                    <i class="bi bi-list"></i>
                </button>

                <div>
                    <h1 class="page-title"><?php echo $__env->yieldContent('page_title', 'Dashboard'); ?></h1>
                    <div class="page-subtitle"><?php echo $__env->yieldContent('page_subtitle'); ?></div>
                </div>

                <div class="dropdown ms-auto">
                    <button class="btn user-menu dropdown-toggle" data-bs-toggle="dropdown" type="button">
                        <span class="user-avatar">
                            <?php echo e(mb_strtoupper(mb_substr(auth()->user()->name, 0, 1))); ?>

                        </span>
                        <span class="d-none d-md-inline">
                            <?php echo e(auth()->user()->name); ?>

                        </span>
                    </button>

                    <ul class="dropdown-menu dropdown-menu-end shadow-sm">
                        <li>
                            <a class="dropdown-item" href="<?php echo e(route('profile.edit')); ?>">
                                <i class="bi bi-person me-2"></i>Hồ sơ
                            </a>
                        </li>
                        <li>
                            <hr class="dropdown-divider">
                        </li>
                        <li>
                            <form method="POST" action="<?php echo e(route('logout')); ?>">
                                <?php echo csrf_field(); ?>
                                <button class="dropdown-item text-danger" type="submit">
                                    <i class="bi bi-box-arrow-right me-2"></i>Đăng xuất
                                </button>
                            </form>
                        </li>
                    </ul>
                </div>
            </header>

            <section class="content-area">
                <?php echo $__env->make('partials.flash', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php echo $__env->yieldContent('content'); ?>
            </section>

            <footer class="app-footer">
                <span>NTP_PLC</span>
                <span>Nhựa Tiền Phong</span>
            </footer>
        </main>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.getElementById('sidebarToggle')?.addEventListener('click', function() {
            document.getElementById('sidebar')?.classList.toggle('show');
        });
    </script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>

</html>
<?php /**PATH D:\xampp\htdocs\NTP_PLC\resources\views/layouts/app.blade.php ENDPATH**/ ?>