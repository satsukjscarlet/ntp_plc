<?php $__env->startSection('title', 'Báo cáo tình hình sản xuất ngày'); ?>
<?php $__env->startSection('page_title', 'Báo cáo tình hình sản xuất ngày chi tiết'); ?>
<?php $__env->startSection('page_subtitle', 'Tổng hợp trực tiếp từ các phiếu kiểm nhập sản lượng'); ?>

<?php $__env->startPush('styles'); ?>
<style>
    /* Bố cục báo cáo gọn: ưu tiên diện tích hiển thị bảng */
    .compact-filter-card { margin-bottom: .55rem !important; }
    .compact-filter-card .card-body { padding: .55rem .75rem; }
    .compact-filter-form { row-gap: .45rem !important; }
    .compact-filter-form .form-label {
        margin-bottom: .15rem;
        font-size: .72rem;
        font-weight: 600;
        color: #667085;
    }
    .compact-filter-form .form-control,
    .compact-filter-form .form-select,
    .compact-filter-form .btn {
        min-height: 32px;
        padding-top: .25rem;
        padding-bottom: .25rem;
        font-size: .82rem;
    }
    .compact-filter-actions {
        display: flex;
        align-items: end;
        gap: .35rem;
        flex-wrap: nowrap;
    }
    .compact-filter-actions .btn { white-space: nowrap; }

    .summary-strip {
        display: flex;
        gap: .45rem;
        overflow-x: auto;
        padding: .1rem .05rem .45rem;
        margin-bottom: .35rem;
        scrollbar-width: thin;
    }
    .summary-chip {
        min-width: 145px;
        flex: 1 0 145px;
        border: 1px solid #dee2e6;
        border-radius: .45rem;
        background: #fff;
        padding: .38rem .55rem;
        box-shadow: 0 .08rem .25rem rgba(0,0,0,.05);
    }
    .summary-chip .label {
        display: block;
        color: #6c757d;
        font-size: .69rem;
        line-height: 1.1;
        white-space: nowrap;
    }
    .summary-chip .value {
        display: block;
        margin-top: .15rem;
        font-size: .94rem;
        line-height: 1.15;
        font-weight: 700;
        white-space: nowrap;
    }

    .report-card-header { padding: .38rem .75rem; }
    .report-card-header h5 { font-size: .92rem; }
    .report-card-header small { font-size: .72rem; }

    .report-table { font-size: .75rem; white-space: nowrap; }
    .report-table th { vertical-align: middle; text-align: center; background: #eef2f5; padding: .34rem .38rem; }
    .report-table td { vertical-align: middle; padding: .3rem .38rem; }
    .report-table-scroll {
        height: calc(100vh - 245px);
        min-height: 420px;
        overflow: auto;
        position: relative;
        scrollbar-gutter: stable;
    }
    .report-table thead th {
        position: sticky;
        z-index: 20;
        background: #eef2f5;
        box-shadow: inset 0 -1px 0 #cfd6dc;
    }
    .report-table thead tr:first-child th { top: 0; }
    .report-table thead tr:nth-child(2) th {
        top: var(--report-header-row-1-height, 34px);
        z-index: 21;
    }
    .report-table thead th[rowspan="2"] { z-index: 22; }
    .report-table .daily-total td { background: #d9dde1; font-weight: 700; }

    @media (max-width: 1199.98px) {
        .compact-filter-actions { flex-wrap: wrap; }
        .report-table-scroll { height: calc(100vh - 305px); }
    }
    @media print {
        .sidebar, .topbar, .app-footer, .report-actions, .filter-card, .summary-strip { display: none !important; }
        .main-area { margin-left: 0 !important; }
        .content-area { padding: 0 !important; }
        .card { border: 0 !important; box-shadow: none !important; }
        .report-table-scroll { height: auto !important; overflow: visible !important; }
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<div class="card shadow-sm filter-card compact-filter-card">
    <div class="card-body">
        <form method="GET" action="<?php echo e(route('production-reports.daily-detail')); ?>" class="row gx-2 compact-filter-form align-items-end">
            <div class="col-6 col-md-2 col-xl-1">
                <label class="form-label">Từ ngày</label>
                <input type="date" name="date_from" class="form-control form-control-sm" value="<?php echo e($filters['date_from']); ?>">
            </div>
            <div class="col-6 col-md-2 col-xl-1">
                <label class="form-label">Đến ngày</label>
                <input type="date" name="date_to" class="form-control form-control-sm" value="<?php echo e($filters['date_to']); ?>">
            </div>
            <div class="col-6 col-md-2 col-xl-2">
                <label class="form-label">Máy</label>
                <select name="machine_id" class="form-select form-select-sm">
                    <option value="">Tất cả</option>
                    <?php $__currentLoopData = $machines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $machine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($machine->id); ?>" <?php if((string)$filters['machine_id'] === (string)$machine->id): echo 'selected'; endif; ?>>
                            <?php echo e($machine->code); ?> - <?php echo e($machine->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-6 col-md-3 col-xl-3">
                <label class="form-label">Sản phẩm</label>
                <select name="product_id" class="form-select form-select-sm">
                    <option value="">Tất cả</option>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($product->id); ?>" <?php if((string)$filters['product_id'] === (string)$product->id): echo 'selected'; endif; ?>>
                            <?php echo e($product->material_code); ?> - <?php echo e($product->material_name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-6 col-md-3 col-xl-2">
                <label class="form-label">Trạng thái</label>
                <select name="status" class="form-select form-select-sm">
                    <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($value); ?>" <?php if($filters['status'] === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-12 col-xl-3 report-actions compact-filter-actions">
                <button class="btn btn-primary btn-sm" type="submit"><i class="bi bi-search"></i> Lọc</button>
                <a class="btn btn-success btn-sm" href="<?php echo e(route('production-reports.daily-detail.excel', request()->query())); ?>">
                    <i class="bi bi-file-earmark-excel"></i> Excel
                </a>
                <button class="btn btn-outline-secondary btn-sm" type="button" onclick="window.print()"><i class="bi bi-printer"></i> In</button>
                <a class="btn btn-outline-secondary btn-sm" href="<?php echo e(route('production-reports.daily-detail')); ?>">Đặt lại</a>
            </div>
        </form>
    </div>
</div>

<?php
    $cards = [
        ['Phiếu sản xuất', number_format($summary['declaration_count'], 0, ',', '.'), 'bi-file-earmark-text'],
        ['Máy sản xuất', number_format($summary['machine_count'], 0, ',', '.'), 'bi-gear-wide-connected'],
        ['Tổng sản lượng', number_format($summary['total_quantity'], 3, ',', '.') . ' ĐVT', 'bi-boxes'],
        ['Chính phẩm', number_format($summary['good_quantity'], 3, ',', '.') . ' ĐVT', 'bi-check-circle'],
        ['Phế phẩm', number_format($summary['reject_quantity'], 3, ',', '.') . ' ĐVT', 'bi-x-circle'],
        ['Phế liệu', number_format($summary['scrap_kg'], 3, ',', '.') . ' kg', 'bi-recycle'],
        ['Trọng lượng', number_format($summary['total_weight_kg'], 3, ',', '.') . ' kg', 'bi-speedometer'],
        ['Giờ dừng', number_format($summary['downtime_minutes'] / 60, 2, ',', '.') . ' giờ', 'bi-stopwatch'],
            ['Bất thường', number_format($summary['issue_count'], 0, ',', '.') . ' dòng', 'bi-exclamation-triangle'],
    ];
?>
<div class="summary-strip">
    <?php $__currentLoopData = $cards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$label, $value, $icon]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="summary-chip">
            <span class="label"><i class="bi <?php echo e($icon); ?> me-1"></i><?php echo e($label); ?></span>
            <span class="value"><?php echo e($value); ?></span>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<div class="card shadow-sm">
    <div class="card-header bg-white text-center report-card-header">
        <h5 class="mb-0 fw-bold">TÌNH HÌNH SẢN XUẤT NGÀY CHI TIẾT</h5>
        <small class="text-muted">Từ <?php echo e(\Carbon\Carbon::parse($filters['date_from'])->format('d/m/Y')); ?> đến <?php echo e(\Carbon\Carbon::parse($filters['date_to'])->format('d/m/Y')); ?></small>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive report-table-scroll" id="dailyReportTableScroll">
            <table class="table table-bordered table-hover report-table mb-0" id="dailyReportTable">
                <thead>
                    <tr>
                        <th rowspan="2">Ngày</th>
                        <th rowspan="2">Mã máy</th>
                        <th rowspan="2">Tên máy</th>
                        <th rowspan="2">Mã sản phẩm</th>
                        <th rowspan="2">Tên sản phẩm</th>
                        <th rowspan="2">ĐVT</th>
                        <th colspan="<?php echo e(max(1, $shifts->count())); ?>">Số lượng</th>
                        <th rowspan="2">Tổng SL</th>
                        <th rowspan="2">Chính phẩm</th>
                        <th rowspan="2">Phế phẩm</th>
                        <th rowspan="2">Phế liệu kg</th>
                        <th rowspan="2">Số m/ĐVT</th>
                        <th rowspan="2">KL chuẩn g/ĐVT</th>
                        <th colspan="<?php echo e(max(1, $shifts->count())); ?>">Trọng lượng kg</th>
                        <th rowspan="2">Tổng KL kg</th>
                        <th rowspan="2">Giờ dừng</th>
                        <th rowspan="2">Mã nguyên nhân</th>
                        <th rowspan="2">Nguyên nhân dừng</th>
                        <th rowspan="2">Ghi chú</th>
                        <th rowspan="2">Kiểm tra dữ liệu</th>
                        <th rowspan="2">Phiếu nguồn</th>
                    </tr>
                    <tr>
                        <?php $__empty_1 = true; $__currentLoopData = $shifts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shift): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><th><?php echo e($shift->name ?: $shift->code); ?></th><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><th>Ca</th><?php endif; ?>
                        <?php $__empty_1 = true; $__currentLoopData = $shifts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shift): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><th><?php echo e($shift->name ?: $shift->code); ?></th><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><th>Ca</th><?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $rows->groupBy(fn($row) => $row['date']->format('Y-m-d')); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dateKey => $dateRows): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php $__currentLoopData = $dateRows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($row['date']->format('d/m/Y')); ?></td>
                                <td><?php echo e($row['machine_code']); ?></td>
                                <td><?php echo e($row['machine_name']); ?></td>
                                <td><?php echo e($row['product_code']); ?></td>
                                <td class="text-wrap" style="min-width:180px"><?php echo e($row['product_name']); ?></td>
                                <td class="text-center"><?php echo e($row['unit']); ?></td>
                                <?php $__currentLoopData = $shifts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shift): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><td class="text-end"><?php echo e(number_format($row['quantities'][$shift->id] ?? 0, 3, ',', '.')); ?></td><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <td class="text-end fw-semibold"><?php echo e(number_format($row['total_quantity'], 3, ',', '.')); ?></td>
                                <td class="text-end"><?php echo e(number_format($row['good_quantity'], 3, ',', '.')); ?></td>
                                <td class="text-end"><?php echo e(number_format($row['reject_quantity'], 3, ',', '.')); ?></td>
                                <td class="text-end"><?php echo e(number_format($row['scrap_kg'], 3, ',', '.')); ?></td>
                                <td class="text-end"><?php echo e(number_format($row['actual_length_m'], 3, ',', '.')); ?></td>
                                <td class="text-end"><?php echo e(number_format($row['standard_weight_g'], 3, ',', '.')); ?></td>
                                <?php $__currentLoopData = $shifts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shift): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><td class="text-end"><?php echo e(number_format($row['weights'][$shift->id] ?? 0, 3, ',', '.')); ?></td><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <td class="text-end fw-semibold"><?php echo e(number_format($row['total_weight_kg'], 3, ',', '.')); ?></td>
                                <td class="text-end"><?php echo e(number_format($row['downtime_minutes'] / 60, 2, ',', '.')); ?></td>
                                <td><?php echo e(implode(', ', $row['downtime_codes'])); ?></td>
                                <td class="text-wrap" style="min-width:180px"><?php echo e(implode('; ', $row['downtime_reasons'])); ?></td>
                                <td class="text-wrap" style="min-width:180px"><?php echo e(implode('; ', $row['notes'])); ?></td>
                                <td class="text-wrap" style="min-width:220px">
                                    <?php $__empty_2 = true; $__currentLoopData = $row['issues']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $issue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                        <span class="badge text-bg-warning me-1 mb-1"><?php echo e($issue); ?></span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                        <span class="badge text-bg-success">Hợp lệ</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-nowrap">
                                    <?php $__currentLoopData = $row['declaration_ids']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $declarationId): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a class="btn btn-sm btn-outline-primary mb-1" href="<?php echo e(route('production-declarations.show', $declarationId)); ?>" title="Mở phiếu #<?php echo e($declarationId); ?>">#<?php echo e($declarationId); ?></a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php ($total = $dailyTotals[$dateKey]); ?>
                        <tr class="daily-total">
                            <td colspan="6" class="text-end">Tổng ngày <?php echo e($total['date']->format('d/m/Y')); ?></td>
                            <?php $__currentLoopData = $shifts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shift): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><td class="text-end"><?php echo e(number_format($total['quantities'][$shift->id] ?? 0, 3, ',', '.')); ?></td><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <td class="text-end"><?php echo e(number_format($total['total_quantity'], 3, ',', '.')); ?></td>
                            <td class="text-end"><?php echo e(number_format($total['good_quantity'], 3, ',', '.')); ?></td>
                            <td class="text-end"><?php echo e(number_format($total['reject_quantity'], 3, ',', '.')); ?></td>
                            <td class="text-end"><?php echo e(number_format($total['scrap_kg'], 3, ',', '.')); ?></td>
                            <td colspan="2"></td>
                            <?php $__currentLoopData = $shifts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shift): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><td class="text-end"><?php echo e(number_format($total['weights'][$shift->id] ?? 0, 3, ',', '.')); ?></td><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <td class="text-end"><?php echo e(number_format($total['total_weight_kg'], 3, ',', '.')); ?></td>
                            <td class="text-end"><?php echo e(number_format($total['downtime_minutes'] / 60, 2, ',', '.')); ?></td>
                            <td colspan="5"></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="<?php echo e(20 + ($shifts->count() * 2)); ?>" class="text-center py-5 text-muted">Không có dữ liệu phù hợp bộ lọc.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->startPush('scripts'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const table = document.getElementById('dailyReportTable');
        if (!table || !table.tHead || !table.tHead.rows.length) return;

        const updateStickyHeaderOffset = function () {
            const firstHeaderRow = table.tHead.rows[0];
            table.style.setProperty('--report-header-row-1-height', firstHeaderRow.getBoundingClientRect().height + 'px');
        };

        updateStickyHeaderOffset();
        window.addEventListener('resize', updateStickyHeaderOffset);
    });
</script>
<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\NTP_PLC\resources\views/production-reports/daily-detail.blade.php ENDPATH**/ ?>