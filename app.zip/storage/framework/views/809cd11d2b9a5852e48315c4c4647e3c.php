<?php $__env->startSection('title', 'Vai trò - NTP_PLC'); ?>
<?php $__env->startSection('page_title', 'Vai trò và quyền'); ?>
<?php $__env->startSection('page_subtitle', 'Phân quyền truy cập hệ thống'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-end mb-3">
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roles.create')): ?>
        <a href="<?php echo e(route('roles.create')); ?>" class="btn btn-primary">
            <i class="bi bi-plus-lg me-1"></i>Thêm vai trò
        </a>
    <?php endif; ?>
</div>

<div class="card panel-card">
    <div class="table-responsive">
        <table class="table align-middle mb-0">
            <thead>
            <tr>
                <th>Vai trò</th>
                <th>Số quyền</th>
                <th>Người dùng</th>
                <th class="text-end">Thao tác</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="fw-semibold"><?php echo e($role->name); ?></td>
                    <td><?php echo e($role->permissions_count); ?></td>
                    <td><?php echo e($role->users_count); ?></td>
                    <td class="text-end">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roles.update')): ?>
                            <a
                                href="<?php echo e(route('roles.edit', $role)); ?>"
                                class="btn btn-sm btn-outline-primary"
                            >
                                Sửa
                            </a>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roles.delete')): ?>
                            <form
                                class="d-inline"
                                method="POST"
                                action="<?php echo e(route('roles.destroy', $role)); ?>"
                            >
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button
                                    class="btn btn-sm btn-outline-danger"
                                    onclick="return confirm('Xóa vai trò này?')"
                                >
                                    Xóa
                                </button>
                            </form>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <?php if($roles->hasPages()): ?>
        <div class="card-footer">
            <?php echo e($roles->links()); ?>

        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\NTP_PLC\resources\views/roles/index.blade.php ENDPATH**/ ?>