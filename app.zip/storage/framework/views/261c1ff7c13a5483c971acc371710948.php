<?php $__env->startSection('title', 'Người dùng - NTP_PLC'); ?>
<?php $__env->startSection('page_title', 'Người dùng'); ?>
<?php $__env->startSection('page_subtitle', 'Quản lý tài khoản và vai trò'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-end mb-3">
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('users.create')): ?>
        <a href="<?php echo e(route('users.create')); ?>" class="btn btn-primary">
            <i class="bi bi-plus-lg me-1"></i>Thêm người dùng
        </a>
    <?php endif; ?>
</div>

<div class="card panel-card">
    <div class="table-responsive">
        <table class="table align-middle mb-0">
            <thead>
            <tr>
                <th>Tên đăng nhập</th>
                <th>Mã NV</th>
                <th>Họ tên</th>
                <th>Email</th>
                <th>Đơn vị</th>
                <th>Vai trò</th>
                <th>Trạng thái</th>
                <th class="text-end">Thao tác</th>
            </tr>
            </thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><code><?php echo e($user->username); ?></code></td>
                    <td><?php echo e($user->employee_code ?: '—'); ?></td>
                    <td class="fw-semibold"><?php echo e($user->name); ?></td>
                    <td><?php echo e($user->email ?: '—'); ?></td>
                    <td>
                        <div><?php echo e($user->department ?: '—'); ?></div>
                        <small class="text-secondary"><?php echo e($user->position); ?></small>
                    </td>
                    <td>
                        <?php $__empty_2 = true; $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                            <span class="badge text-bg-primary"><?php echo e($role->name); ?></span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                            <span class="text-secondary">Chưa gán</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <span class="badge <?php echo e($user->is_active ? 'text-bg-success' : 'text-bg-secondary'); ?>">
                            <?php echo e($user->is_active ? 'Hoạt động' : 'Đã khóa'); ?>

                        </span>
                    </td>
                    <td class="text-end text-nowrap">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('users.update')): ?>
                            <a
                                href="<?php echo e(route('users.edit', $user)); ?>"
                                class="btn btn-sm btn-outline-primary"
                            >
                                Sửa
                            </a>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('users.activate')): ?>
                            <form
                                class="d-inline"
                                method="POST"
                                action="<?php echo e(route('users.toggle-active', $user)); ?>"
                            >
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PATCH'); ?>
                                <button
                                    class="btn btn-sm btn-outline-warning"
                                    onclick="return confirm('Xác nhận thay đổi trạng thái tài khoản?')"
                                >
                                    <?php echo e($user->is_active ? 'Khóa' : 'Mở khóa'); ?>

                                </button>
                            </form>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('users.delete')): ?>
                            <form
                                class="d-inline"
                                method="POST"
                                action="<?php echo e(route('users.destroy', $user)); ?>"
                            >
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button
                                    class="btn btn-sm btn-outline-danger"
                                    onclick="return confirm('Bạn chắc chắn muốn xóa người dùng này?')"
                                >
                                    Xóa
                                </button>
                            </form>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="8" class="text-center py-5 text-secondary">
                        Chưa có người dùng.
                    </td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>

    <?php if($users->hasPages()): ?>
        <div class="card-footer">
            <?php echo e($users->links()); ?>

        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\NTP_PLC\resources\views/users/index.blade.php ENDPATH**/ ?>